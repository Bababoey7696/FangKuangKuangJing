package com.ame.blocktetris;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class BlockTetrisView extends View {
    private static final int COLS = 10;
    private static final int ROWS = 20;

    // Coordinates are stored as x,y pairs inside a 4x4 piece box.
    private static final int[][][] SHAPES = new int[][][] {
        { // I
            {0,1, 1,1, 2,1, 3,1}, {2,0, 2,1, 2,2, 2,3},
            {0,2, 1,2, 2,2, 3,2}, {1,0, 1,1, 1,2, 1,3}
        },
        { // O
            {1,0, 2,0, 1,1, 2,1}, {1,0, 2,0, 1,1, 2,1},
            {1,0, 2,0, 1,1, 2,1}, {1,0, 2,0, 1,1, 2,1}
        },
        { // T
            {1,0, 0,1, 1,1, 2,1}, {1,0, 1,1, 2,1, 1,2},
            {0,1, 1,1, 2,1, 1,2}, {1,0, 0,1, 1,1, 1,2}
        },
        { // S
            {1,0, 2,0, 0,1, 1,1}, {1,0, 1,1, 2,1, 2,2},
            {1,1, 2,1, 0,2, 1,2}, {0,0, 0,1, 1,1, 1,2}
        },
        { // Z
            {0,0, 1,0, 1,1, 2,1}, {2,0, 1,1, 2,1, 1,2},
            {0,1, 1,1, 1,2, 2,2}, {1,0, 0,1, 1,1, 0,2}
        },
        { // J
            {0,0, 0,1, 1,1, 2,1}, {1,0, 2,0, 1,1, 1,2},
            {0,1, 1,1, 2,1, 2,2}, {1,0, 1,1, 0,2, 1,2}
        },
        { // L
            {2,0, 0,1, 1,1, 2,1}, {1,0, 1,1, 1,2, 2,2},
            {0,1, 1,1, 2,1, 0,2}, {0,0, 1,0, 1,1, 1,2}
        }
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pixelPaint = new Paint();
    private final Random random = new Random();
    private final SharedPreferences prefs;
    private final int[][] board = new int[ROWS][COLS];
    private final int[] bag = new int[7];
    private int bagIndex = 7;

    private int currentType;
    private int nextType;
    private int rotation;
    private int pieceX;
    private int pieceY;
    private int score;
    private int highScore;
    private int lines;
    private int level;
    private boolean paused;
    private boolean gameOver;
    private boolean started;

    private float cell;
    private float boardLeft;
    private float boardTop;
    private float boardRight;
    private float boardBottom;
    private float density;

    private final RectF leftButton = new RectF();
    private final RectF rotateButton = new RectF();
    private final RectF rightButton = new RectF();
    private final RectF downButton = new RectF();
    private final RectF dropButton = new RectF();
    private final RectF pauseButton = new RectF();
    private final RectF restartButton = new RectF();

    private String banner = "";
    private long bannerUntil;
    private long lastTick;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            if (!paused && !gameOver && started && now - lastTick >= dropInterval()) {
                stepDown(false);
                lastTick = now;
            }
            invalidate();
            postDelayed(this, 32);
        }
    };

    public BlockTetrisView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        prefs = context.getSharedPreferences("block_tetris", Context.MODE_PRIVATE);
        highScore = prefs.getInt("high_score", 0);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        setFocusable(true);
        startNewGame();
        removeCallbacks(loop);
        post(loop);
    }

    public void refreshSystemUi() {
        setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LOW_PROFILE);
    }

    public void pauseForBackground() {
        if (!gameOver) paused = true;
        invalidate();
    }

    private void startNewGame() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) board[r][c] = 0;
        }
        score = 0;
        lines = 0;
        level = 1;
        paused = false;
        gameOver = false;
        started = true;
        bagIndex = 7;
        nextType = takeFromBag();
        spawnPiece();
        lastTick = System.currentTimeMillis();
        banner = "开始采矿！";
        bannerUntil = lastTick + 1200;
        invalidate();
    }

    private void fillBag() {
        for (int i = 0; i < 7; i++) bag[i] = i;
        for (int i = 6; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int t = bag[i]; bag[i] = bag[j]; bag[j] = t;
        }
        bagIndex = 0;
    }

    private int takeFromBag() {
        if (bagIndex >= 7) fillBag();
        return bag[bagIndex++];
    }

    private void spawnPiece() {
        currentType = nextType;
        nextType = takeFromBag();
        rotation = 0;
        pieceX = 3;
        pieceY = -1;
        if (collides(pieceX, pieceY, rotation)) {
            gameOver = true;
            paused = false;
            if (score > highScore) {
                highScore = score;
                prefs.edit().putInt("high_score", highScore).apply();
            }
        }
    }

    private long dropInterval() {
        long value = 720L - (level - 1) * 55L;
        return Math.max(95L, value);
    }

    private boolean collides(int x, int y, int rot) {
        int[] s = SHAPES[currentType][rot];
        for (int i = 0; i < 8; i += 2) {
            int bx = x + s[i];
            int by = y + s[i + 1];
            if (bx < 0 || bx >= COLS || by >= ROWS) return true;
            if (by >= 0 && board[by][bx] != 0) return true;
        }
        return false;
    }

    private void move(int dx) {
        if (paused || gameOver) return;
        if (!collides(pieceX + dx, pieceY, rotation)) pieceX += dx;
        invalidate();
    }

    private void rotatePiece() {
        if (paused || gameOver) return;
        int nr = (rotation + 1) % 4;
        if (!collides(pieceX, pieceY, nr)) {
            rotation = nr;
        } else if (!collides(pieceX - 1, pieceY, nr)) {
            pieceX--; rotation = nr;
        } else if (!collides(pieceX + 1, pieceY, nr)) {
            pieceX++; rotation = nr;
        } else if (!collides(pieceX - 2, pieceY, nr)) {
            pieceX -= 2; rotation = nr;
        } else if (!collides(pieceX + 2, pieceY, nr)) {
            pieceX += 2; rotation = nr;
        }
        invalidate();
    }

    private void stepDown(boolean manual) {
        if (paused || gameOver) return;
        if (!collides(pieceX, pieceY + 1, rotation)) {
            pieceY++;
            if (manual) score += 1;
        } else {
            lockPiece();
        }
    }

    private void hardDrop() {
        if (paused || gameOver) return;
        int distance = 0;
        while (!collides(pieceX, pieceY + 1, rotation)) {
            pieceY++;
            distance++;
        }
        score += distance * 2;
        lockPiece();
    }

    private void lockPiece() {
        int[] s = SHAPES[currentType][rotation];
        boolean aboveTop = false;
        for (int i = 0; i < 8; i += 2) {
            int bx = pieceX + s[i];
            int by = pieceY + s[i + 1];
            if (by < 0) aboveTop = true;
            else if (by < ROWS && bx >= 0 && bx < COLS) board[by][bx] = currentType + 1;
        }
        if (aboveTop) {
            gameOver = true;
            return;
        }
        clearLines();
        if (!gameOver) spawnPiece();
        lastTick = System.currentTimeMillis();
    }

    private void clearLines() {
        int cleared = 0;
        for (int r = ROWS - 1; r >= 0; r--) {
            boolean full = true;
            for (int c = 0; c < COLS; c++) {
                if (board[r][c] == 0) { full = false; break; }
            }
            if (full) {
                cleared++;
                for (int rr = r; rr > 0; rr--) {
                    for (int c = 0; c < COLS; c++) board[rr][c] = board[rr - 1][c];
                }
                for (int c = 0; c < COLS; c++) board[0][c] = 0;
                r++;
            }
        }
        if (cleared > 0) {
            int[] points = {0, 100, 300, 500, 800};
            score += points[cleared] * level;
            lines += cleared;
            level = 1 + lines / 10;
            banner = cleared == 4 ? "稀有矿脉！四行清除" : "矿层清除 × " + cleared;
            bannerUntil = System.currentTimeMillis() + 1100;
            if (score > highScore) {
                highScore = score;
                prefs.edit().putInt("high_score", highScore).apply();
            }
        }
    }

    private int ghostY() {
        int y = pieceY;
        while (!collides(pieceX, y + 1, rotation)) y++;
        return y;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float topSpace = h * 0.115f;
        float controlsTop = h * 0.775f;
        float availableHeight = controlsTop - topSpace - 8f * density;
        float availableWidth = w * 0.72f;
        cell = Math.min(availableWidth / COLS, availableHeight / ROWS);
        boardLeft = w * 0.045f;
        boardTop = topSpace;
        boardRight = boardLeft + COLS * cell;
        boardBottom = boardTop + ROWS * cell;

        float gap = 9f * density;
        float margin = w * 0.045f;
        float buttonW = (w - margin * 2 - gap * 3) / 4f;
        float row1Top = controlsTop + 8f * density;
        float row1H = Math.min(h * 0.085f, 78f * density);
        leftButton.set(margin, row1Top, margin + buttonW, row1Top + row1H);
        rotateButton.set(leftButton.right + gap, row1Top, leftButton.right + gap + buttonW, row1Top + row1H);
        rightButton.set(rotateButton.right + gap, row1Top, rotateButton.right + gap + buttonW, row1Top + row1H);
        downButton.set(rightButton.right + gap, row1Top, rightButton.right + gap + buttonW, row1Top + row1H);

        float row2Top = row1Top + row1H + gap;
        float row2H = Math.min(h * 0.075f, 70f * density);
        float wide = (w - margin * 2 - gap) / 2f;
        dropButton.set(margin, row2Top, margin + wide, row2Top + row2H);
        pauseButton.set(dropButton.right + gap, row2Top, dropButton.right + gap + wide, row2Top + row2H);

        restartButton.set(w * 0.23f, h * 0.57f, w * 0.77f, h * 0.64f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawWorldBackground(canvas);
        drawHeader(canvas);
        drawBoardFrame(canvas);
        drawBoard(canvas);
        drawSidePanel(canvas);
        drawControls(canvas);
        drawBanner(canvas);
        if (paused && !gameOver) drawOverlay(canvas, "已暂停", "点击右下按钮继续");
        if (gameOver) drawGameOver(canvas);
    }

    private void drawWorldBackground(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        canvas.drawColor(Color.rgb(102, 181, 218));
        pixelPaint.setColor(Color.rgb(218, 244, 249));
        drawPixelCloud(canvas, w * 0.08f, h * 0.035f, w * 0.24f);
        drawPixelCloud(canvas, w * 0.67f, h * 0.075f, w * 0.20f);

        float groundTop = h * 0.755f;
        pixelPaint.setColor(Color.rgb(82, 151, 69));
        canvas.drawRect(0, groundTop, w, groundTop + 18f * density, pixelPaint);
        pixelPaint.setColor(Color.rgb(119, 78, 48));
        canvas.drawRect(0, groundTop + 18f * density, w, h, pixelPaint);
        int tile = Math.max(12, (int)(18f * density));
        for (int y = (int)groundTop + tile; y < h; y += tile) {
            for (int x = 0; x < w; x += tile) {
                int seed = (x / tile) * 23 + (y / tile) * 41;
                pixelPaint.setColor((seed & 1) == 0 ? Color.rgb(103, 65, 42) : Color.rgb(132, 86, 51));
                canvas.drawRect(x + tile * 0.18f, y + tile * 0.22f,
                        x + tile * 0.46f, y + tile * 0.46f, pixelPaint);
            }
        }
    }

    private void drawPixelCloud(Canvas canvas, float x, float y, float width) {
        float u = width / 6f;
        canvas.drawRect(x + u, y, x + 4*u, y + u, pixelPaint);
        canvas.drawRect(x, y + u, x + 5*u, y + 2*u, pixelPaint);
        canvas.drawRect(x + 2*u, y - u, x + 4*u, y + u, pixelPaint);
    }

    private void drawHeader(Canvas canvas) {
        float w = getWidth();
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(44, 36, 28));
        paint.setTextSize(Math.min(30f * density, w * 0.075f));
        canvas.drawText("方块矿境", w / 2f + 2f * density, 43f * density + 2f * density, paint);
        paint.setColor(Color.rgb(245, 245, 220));
        canvas.drawText("方块矿境", w / 2f, 43f * density, paint);
        paint.setTextSize(Math.min(12f * density, w * 0.03f));
        paint.setColor(Color.rgb(46, 76, 79));
        canvas.drawText("BLOCK MINE TETRIS", w / 2f, 61f * density, paint);
    }

    private void drawBoardFrame(Canvas canvas) {
        float pad = 7f * density;
        pixelPaint.setColor(Color.rgb(56, 39, 29));
        canvas.drawRect(boardLeft - pad, boardTop - pad, boardRight + pad, boardBottom + pad, pixelPaint);
        pixelPaint.setColor(Color.rgb(118, 77, 45));
        canvas.drawRect(boardLeft - 3f*density, boardTop - 3f*density,
                boardRight + 3f*density, boardBottom + 3f*density, pixelPaint);
        pixelPaint.setColor(Color.rgb(26, 34, 38));
        canvas.drawRect(boardLeft, boardTop, boardRight, boardBottom, pixelPaint);
    }

    private void drawBoard(Canvas canvas) {
        pixelPaint.setStyle(Paint.Style.FILL);
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                float x = boardLeft + c * cell;
                float y = boardTop + r * cell;
                pixelPaint.setColor(((r + c) & 1) == 0 ? Color.rgb(29, 40, 43) : Color.rgb(32, 44, 47));
                canvas.drawRect(x, y, x + cell, y + cell, pixelPaint);
                pixelPaint.setColor(Color.argb(34, 255, 255, 255));
                pixelPaint.setStyle(Paint.Style.STROKE);
                pixelPaint.setStrokeWidth(1f);
                canvas.drawRect(x, y, x + cell, y + cell, pixelPaint);
                pixelPaint.setStyle(Paint.Style.FILL);
                if (board[r][c] != 0) drawBlock(canvas, x, y, cell, board[r][c] - 1, c, r, 255);
            }
        }

        if (!gameOver) {
            int gy = ghostY();
            int[] ghost = SHAPES[currentType][rotation];
            for (int i = 0; i < 8; i += 2) {
                int bx = pieceX + ghost[i];
                int by = gy + ghost[i + 1];
                if (by >= 0) drawGhost(canvas, boardLeft + bx*cell, boardTop + by*cell, cell, currentType);
            }
            int[] s = SHAPES[currentType][rotation];
            for (int i = 0; i < 8; i += 2) {
                int bx = pieceX + s[i];
                int by = pieceY + s[i + 1];
                if (by >= 0) drawBlock(canvas, boardLeft + bx*cell, boardTop + by*cell,
                        cell, currentType, bx, by, 255);
            }
        }
    }

    private void drawGhost(Canvas canvas, float x, float y, float size, int type) {
        int[] base = baseColors(type);
        pixelPaint.setColor(Color.argb(85, Color.red(base[0]), Color.green(base[0]), Color.blue(base[0])));
        pixelPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(x + size*0.12f, y + size*0.12f, x + size*0.88f, y + size*0.88f, pixelPaint);
        pixelPaint.setStyle(Paint.Style.STROKE);
        pixelPaint.setStrokeWidth(Math.max(1f, size*0.07f));
        pixelPaint.setColor(Color.argb(135, 225, 245, 228));
        canvas.drawRect(x + size*0.12f, y + size*0.12f, x + size*0.88f, y + size*0.88f, pixelPaint);
        pixelPaint.setStyle(Paint.Style.FILL);
    }

    private int[] baseColors(int type) {
        switch(type) {
            case 0: return new int[]{Color.rgb(91,143,58), Color.rgb(69,111,45), Color.rgb(137,92,53)};
            case 1: return new int[]{Color.rgb(132,137,140), Color.rgb(91,98,103), Color.rgb(174,178,177)};
            case 2: return new int[]{Color.rgb(54,72,80), Color.rgb(31,47,55), Color.rgb(50,218,218)};
            case 3: return new int[]{Color.rgb(160,105,55), Color.rgb(103,61,31), Color.rgb(206,143,73)};
            case 4: return new int[]{Color.rgb(218,194,125), Color.rgb(166,141,84), Color.rgb(241,222,157)};
            case 5: return new int[]{Color.rgb(73,70,76), Color.rgb(42,41,48), Color.rgb(222,76,64)};
            default: return new int[]{Color.rgb(124,78,160), Color.rgb(77,48,112), Color.rgb(208,137,242)};
        }
    }

    private void drawBlock(Canvas canvas, float x, float y, float size, int type, int gx, int gy, int alpha) {
        int[] colors = baseColors(type);
        float gap = Math.max(1f, size * 0.045f);
        pixelPaint.setColor(withAlpha(colors[1], alpha));
        canvas.drawRect(x + gap, y + gap, x + size - gap, y + size - gap, pixelPaint);
        pixelPaint.setColor(withAlpha(colors[0], alpha));
        canvas.drawRect(x + gap, y + gap, x + size - gap, y + size * 0.78f, pixelPaint);
        pixelPaint.setColor(withAlpha(lighten(colors[0], 34), alpha));
        canvas.drawRect(x + gap, y + gap, x + size - gap, y + size * 0.13f, pixelPaint);
        canvas.drawRect(x + gap, y + gap, x + size * 0.12f, y + size - gap, pixelPaint);
        pixelPaint.setColor(withAlpha(darken(colors[1], 24), alpha));
        canvas.drawRect(x + size * 0.84f, y + size * 0.15f, x + size - gap, y + size - gap, pixelPaint);
        canvas.drawRect(x + size * 0.14f, y + size * 0.84f, x + size - gap, y + size - gap, pixelPaint);

        int seed = gx * 97 + gy * 53 + type * 211;
        float p = Math.max(2f, size * 0.13f);
        for (int i = 0; i < 4; i++) {
            int sx = Math.abs(seed + i * 43) % 6;
            int sy = Math.abs(seed * 3 + i * 29) % 6;
            float px = x + size * (0.14f + sx * 0.11f);
            float py = y + size * (0.18f + sy * 0.10f);
            int color;
            if (type == 0 && sy < 2) color = Color.rgb(112, 182, 67);
            else if (type == 2 || type == 5 || type == 6) color = (i < 2 ? colors[2] : lighten(colors[1], 28));
            else color = (i % 2 == 0 ? darken(colors[0], 28) : colors[2]);
            pixelPaint.setColor(withAlpha(color, alpha));
            canvas.drawRect(px, py, px + p, py + p, pixelPaint);
        }

        if (type == 0) {
            pixelPaint.setColor(withAlpha(Color.rgb(126, 79, 43), alpha));
            canvas.drawRect(x + gap, y + size * 0.58f, x + size - gap, y + size * 0.84f, pixelPaint);
            pixelPaint.setColor(withAlpha(Color.rgb(80, 149, 52), alpha));
            canvas.drawRect(x + gap, y + gap, x + size - gap, y + size * 0.30f, pixelPaint);
        }
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private int lighten(int color, int d) {
        return Color.rgb(Math.min(255, Color.red(color)+d), Math.min(255, Color.green(color)+d), Math.min(255, Color.blue(color)+d));
    }

    private int darken(int color, int d) {
        return Color.rgb(Math.max(0, Color.red(color)-d), Math.max(0, Color.green(color)-d), Math.max(0, Color.blue(color)-d));
    }

    private void drawSidePanel(Canvas canvas) {
        float left = boardRight + 12f * density;
        float right = getWidth() - 8f * density;
        float top = boardTop;
        drawPanel(canvas, left, top, right, top + 86f*density);
        drawSmallLabel(canvas, "下一个", (left+right)/2f, top + 18f*density);
        float previewCell = Math.min((right-left)/5f, 18f*density);
        int[] s = SHAPES[nextType][0];
        float ox = (left+right)/2f - previewCell*2f;
        float oy = top + 28f*density;
        for (int i = 0; i < 8; i += 2) {
            drawBlock(canvas, ox + s[i]*previewCell, oy + s[i+1]*previewCell,
                    previewCell, nextType, s[i], s[i+1], 255);
        }

        float infoTop = top + 96f*density;
        drawPanel(canvas, left, infoTop, right, infoTop + 155f*density);
        drawStat(canvas, "分数", String.valueOf(score), left, right, infoTop + 25f*density);
        drawStat(canvas, "最高", String.valueOf(highScore), left, right, infoTop + 67f*density);
        drawStat(canvas, "行数", String.valueOf(lines), left, right, infoTop + 109f*density);
        drawStat(canvas, "等级", String.valueOf(level), left, right, infoTop + 151f*density);

        float legendTop = infoTop + 168f*density;
        if (legendTop + 78f*density < boardBottom) {
            drawPanel(canvas, left, legendTop, right, Math.min(boardBottom, legendTop + 90f*density));
            drawSmallLabel(canvas, "材质图鉴", (left+right)/2f, legendTop + 18f*density);
            float ss = Math.min(14f*density, (right-left-8f*density)/4f);
            for (int i = 0; i < 7; i++) {
                int col = i % 3;
                int row = i / 3;
                float bx = left + 6f*density + col*(ss + 4f*density);
                float by = legendTop + 26f*density + row*(ss + 4f*density);
                drawBlock(canvas, bx, by, ss, i, col, row, 255);
            }
        }
    }

    private void drawPanel(Canvas canvas, float l, float t, float r, float b) {
        pixelPaint.setColor(Color.argb(225, 38, 49, 48));
        canvas.drawRect(l, t, r, b, pixelPaint);
        pixelPaint.setStyle(Paint.Style.STROKE);
        pixelPaint.setStrokeWidth(2f*density);
        pixelPaint.setColor(Color.rgb(125, 84, 49));
        canvas.drawRect(l, t, r, b, pixelPaint);
        pixelPaint.setStyle(Paint.Style.FILL);
    }

    private void drawSmallLabel(Canvas canvas, String text, float x, float y) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(Color.rgb(224, 232, 211));
        paint.setTextSize(11f*density);
        canvas.drawText(text, x, y, paint);
    }

    private void drawStat(Canvas canvas, String label, String value, float left, float right, float y) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(10f*density);
        paint.setColor(Color.rgb(170, 190, 173));
        canvas.drawText(label, (left+right)/2f, y - 9f*density, paint);
        paint.setTextSize(15f*density);
        paint.setColor(Color.rgb(246, 230, 166));
        canvas.drawText(value, (left+right)/2f, y + 8f*density, paint);
    }

    private void drawControls(Canvas canvas) {
        drawButton(canvas, leftButton, "◀", Color.rgb(75, 116, 71));
        drawButton(canvas, rotateButton, "↻", Color.rgb(82, 105, 132));
        drawButton(canvas, rightButton, "▶", Color.rgb(75, 116, 71));
        drawButton(canvas, downButton, "▼", Color.rgb(75, 116, 71));
        drawButton(canvas, dropButton, "快速落地", Color.rgb(138, 91, 47));
        drawButton(canvas, pauseButton, paused ? "继续" : "暂停", Color.rgb(104, 78, 117));
    }

    private void drawButton(Canvas canvas, RectF rect, String text, int color) {
        pixelPaint.setColor(Color.rgb(45, 34, 27));
        canvas.drawRect(rect.left-3f*density, rect.top-3f*density,
                rect.right+3f*density, rect.bottom+3f*density, pixelPaint);
        pixelPaint.setColor(color);
        canvas.drawRect(rect, pixelPaint);
        pixelPaint.setColor(lighten(color, 32));
        canvas.drawRect(rect.left, rect.top, rect.right, rect.top + 6f*density, pixelPaint);
        pixelPaint.setColor(darken(color, 30));
        canvas.drawRect(rect.left, rect.bottom - 6f*density, rect.right, rect.bottom, pixelPaint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(text.length() <= 2 ? 25f*density : 15f*density);
        paint.setColor(Color.WHITE);
        float baseline = rect.centerY() - (paint.ascent() + paint.descent())/2f;
        canvas.drawText(text, rect.centerX(), baseline, paint);
    }

    private void drawBanner(Canvas canvas) {
        if (System.currentTimeMillis() > bannerUntil || banner.length() == 0) return;
        float l = boardLeft + cell;
        float r = boardRight - cell;
        float t = boardTop + cell*8.7f;
        float b = t + 40f*density;
        pixelPaint.setColor(Color.argb(220, 41, 53, 47));
        canvas.drawRect(l, t, r, b, pixelPaint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(14f*density);
        paint.setColor(Color.rgb(246, 225, 132));
        float baseline = (t+b)/2f - (paint.ascent()+paint.descent())/2f;
        canvas.drawText(banner, (l+r)/2f, baseline, paint);
    }

    private void drawOverlay(Canvas canvas, String title, String subtitle) {
        pixelPaint.setColor(Color.argb(190, 12, 18, 18));
        canvas.drawRect(boardLeft, boardTop, boardRight, boardBottom, pixelPaint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(Color.rgb(246, 232, 166));
        paint.setTextSize(25f*density);
        canvas.drawText(title, (boardLeft+boardRight)/2f, boardTop + (boardBottom-boardTop)*0.46f, paint);
        paint.setColor(Color.rgb(220, 231, 219));
        paint.setTextSize(12f*density);
        canvas.drawText(subtitle, (boardLeft+boardRight)/2f, boardTop + (boardBottom-boardTop)*0.52f, paint);
    }

    private void drawGameOver(Canvas canvas) {
        pixelPaint.setColor(Color.argb(215, 13, 17, 17));
        canvas.drawRect(0, 0, getWidth(), getHeight(), pixelPaint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(31f*density);
        paint.setColor(Color.rgb(234, 104, 79));
        canvas.drawText("矿井封闭", getWidth()/2f, getHeight()*0.39f, paint);
        paint.setTextSize(16f*density);
        paint.setColor(Color.rgb(245, 231, 170));
        canvas.drawText("本局分数  " + score, getWidth()/2f, getHeight()*0.46f, paint);
        paint.setTextSize(12f*density);
        paint.setColor(Color.rgb(220, 230, 218));
        canvas.drawText("最高分  " + highScore, getWidth()/2f, getHeight()*0.50f, paint);
        drawButton(canvas, restartButton, "重新开采", Color.rgb(78, 132, 71));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN) return true;
        refreshSystemUi();
        float x = event.getX();
        float y = event.getY();
        if (gameOver) {
            if (restartButton.contains(x, y)) startNewGame();
            return true;
        }
        if (leftButton.contains(x,y)) move(-1);
        else if (rotateButton.contains(x,y)) rotatePiece();
        else if (rightButton.contains(x,y)) move(1);
        else if (downButton.contains(x,y)) stepDown(true);
        else if (dropButton.contains(x,y)) hardDrop();
        else if (pauseButton.contains(x,y)) { paused = !paused; lastTick = System.currentTimeMillis(); invalidate(); }
        else if (!paused && x >= boardLeft && x <= boardRight && y >= boardTop && y <= boardBottom) rotatePiece();
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(loop);
        super.onDetachedFromWindow();
    }
}
